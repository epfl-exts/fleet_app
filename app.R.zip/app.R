source("helpers.R")

new_cars_data <-
  get_data() %>%
  tidy_data()

years <-
  new_cars_data %>%
  pull(year) %>%
  unique()

cantons <-
  new_cars_data %>%
  pull(kanton) %>%
  unique()

metrics <-
  new_cars_data %>%
  select(-kanton,-year) %>%
  colnames()

ui <- fluidPage(sidebarLayout(
  sidebarPanel(
    sliderInput(
      "year",
      "Select year",
      min = min(years),
      max = max(years),
      value = max(years),
      step = 1,
      sep = ""
    ),
    selectInput(
      "cantons",
      "Select Cantons to compare",
      choices = cantons,
      multiple = TRUE,
      selected = c("ZH", "BE", "GE")
    ),
    selectInput(
      "metric",
      "Select Metric to compare",
      choices = metrics,
      selected = "avg_price"
    )
  ),
  mainPanel(plotOutput("bar_plot"),
            textOutput("time_stamp"))
))

server <- function(input, output, session) {
  output$bar_plot <- renderPlot({
    plot_comparison(new_cars_data,
                    input$year,
                    input$cantons,
                    input$metric)
  })

  return_time_each_second <- reactive({
    invalidateLater(1000)
    format(Sys.time(), "%a %b %d %X %Y")
  })

  output$time_stamp <- renderText({
    paste("Compared",
          input$metric,
          "at:",
          isolate(return_time_each_second()))
  })
}

options(shiny.autoreload = TRUE)
shinyApp(ui, server)
